// 
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license.
// 
// Microsoft Cognitive Services: https://azure.microsoft.com/en-us/services/cognitive-services
// 
// Microsoft Cognitive Services GitHub:
// https://github.com/Microsoft/Cognitive-CustomVision-Windows
// 
// Copyright (c) Microsoft Corporation
// All rights reserved.
// 
// MIT License:
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
// 


using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Cognitive.CustomVision;
using Common.Model;
using Microsoft.Rest;
using Microsoft.Cognitive.CustomVision.Training;

namespace Common.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="ITrainingApi"/>
    /// </summary>
    public static class TrainingApiExtensions
    {
        /// <summary>
        /// Create tags for <paramref name="projectId"/> with <paramref name="tagNames"/>
        /// </summary>
        public static async Task CreateTagsAsync(this ITrainingApi trainingApi, Guid projectId, IEnumerable<string> tagNames)
        {
            foreach (var tag in tagNames)
            {
                await trainingApi.CreateTagAsync(projectId, tag);
            }
        }

        /// <summary>
        /// Create a project using <paramref name="project"/>
        /// </summary>
        public static async Task<ProjectInfo> CreateProjectAsync(this ITrainingApi trainingApi, ProjectInfo project)
        {
            var domains = trainingApi.GetDomains();
            var targetDomain = domains.FirstOrDefault(x => string.Equals(x.Name, project.Domain, StringComparison.OrdinalIgnoreCase));
            if (targetDomain == null)
            {
                var supportedDomains = domains.Select(x => x.Name).Aggregate((x, y) => $"{x},{y}");
                throw new InvalidOperationException($"Unsupported domain: {project.Domain}. Must be one of {supportedDomains}");
            }
            
            var projectModel = await trainingApi.CreateProjectAsync(project.Name, project.Description, targetDomain.Id);
            project.Id = projectModel.Id;
            project.ThumbnailUri = projectModel.ThumbnailUri;
            return project;
        }

        /// <summary>
        /// Check if the project exists or not.
        /// </summary>
        public static bool CheckIfProjectExists(this ITrainingApi trainingApi, Guid projectId)
        {
            try
            {
                trainingApi.GetProjectAsync(projectId).Wait();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Check if iteration exists or not.
        /// </summary>
        public static bool CheckIfIterationExists(this ITrainingApi trainingApi, Guid projectId, Guid iterationId)
        {
            try
            {
                trainingApi.GetIterationWithHttpMessagesAsync(projectId, iterationId).Wait();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
